# Expense Management — Hackathon Starter

This repository contains a hackathon-ready starter for an expense management system.

**Features**
- Admin signup and company creation
- Create users (employee/manager/admin)
- Upload receipts
- Approval rules (admin-configurable)
- Manager approve/reject flow
- Currency list from Rest Countries and conversion using exchangerate.host

**Tech stack**
- Backend: Node.js + Express + lowdb (file-based DB) + multer for uploads
- Frontend: React (barebones, single page)

## Quick start (dev)

1. Start backend

```bash
cd backend
npm install
npm run dev
```

2. Start frontend

```bash
cd frontend
npm install
npm start
```

3. Create company + admin (curl)

```bash
curl -X POST http://localhost:4000/api/company/signup -H "Content-Type: application/json" -d '{"companyName":"HackCo","adminEmail":"admin@hackco.test","adminName":"Admin"}'
```

4. Open frontend at http://localhost:3000. Use the demo input to set the `x-user-email` header and test flows.

## Docker (optional)

- Backend Dockerfile included — build and run as needed.
