import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:4000/api';

const DemoHeader = ({ setUser }) => {
  const [email, setEmail] = useState('');
  return (
    <div style={{padding:10, borderBottom:'1px solid #ccc'}}>
      <input placeholder="x-user-email for demo" value={email} onChange={e=>setEmail(e.target.value)} />
      <button onClick={() => setUser(email)}>Set User</button>
      <small style={{marginLeft:10}}>Use admin email created in backend signup to act as admin</small>
    </div>
  );
};

function App() {
  const [userEmail, setUserEmail] = useState('');
  const [expenses, setExpenses] = useState([]);
  const [form, setForm] = useState({ description:'', amount:'', category:'misc', paidBy:'cash', currency:'' });
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ name:'', email:'', role:'employee' });
  const [file, setFile] = useState(null);
  const [countries, setCountries] = useState([]);

  useEffect(()=> { if(userEmail) loadInitial(); }, [userEmail]);

  async function loadInitial(){
    await fetchExpenses();
    try {
      const resp = await axios.get(`${API}/currencies`);
      setCountries(resp.data || []);
    } catch(err){ console.warn('currencies fail', err); }
    try {
      const resp = await axios.get(`${API}/users`, { headers: { 'x-user-email': userEmail } });
      setUsers(resp.data || []);
    } catch(e) { /* may not be admin */ }
  }

  async function fetchExpenses(){
    try {
      const resp = await axios.get(`${API}/expenses`, { headers: { 'x-user-email': userEmail }});
      setExpenses(resp.data);
    } catch(err){ console.error(err); }
  }

  async function submitExpense(e){
    e.preventDefault();
    const fd = new FormData();
    fd.append('description', form.description);
    fd.append('amount', form.amount);
    fd.append('category', form.category);
    fd.append('paidBy', form.paidBy);
    fd.append('currency', form.currency);
    if (file) fd.append('receipt', file);
    try {
      await axios.post(`${API}/expenses`, fd, { headers: { 'x-user-email': userEmail, 'Content-Type': 'multipart/form-data' }});
      setForm({ description:'', amount:'', category:'misc', paidBy:'cash', currency:'' });
      setFile(null);
      fetchExpenses();
    } catch(err){ console.error(err); alert('submit error') }
  }

  async function createUser(e){
    e.preventDefault();
    try {
      await axios.post(`${API}/users`, newUser, { headers: { 'x-user-email': userEmail }});
      setNewUser({ name:'', email:'', role:'employee' });
      const resp = await axios.get(`${API}/users`, { headers: { 'x-user-email': userEmail }});
      setUsers(resp.data);
    } catch(err){ console.error(err); alert('create user failed') }
  }

  async function decision(expenseId, decision){
    try {
      await axios.post(`${API}/expenses/${expenseId}/decision`, { decision }, { headers: { 'x-user-email': userEmail }});
      fetchExpenses();
    } catch(err){ console.error(err); alert('decision failed') }
  }

  return (
    <div style={{padding:20}}>
      <DemoHeader setUser={setUserEmail} />
      <h2>Logged in as: {userEmail || '—'}</h2>

      <section style={{display:'flex', gap:40}}>
        <div style={{flex:1}}>
          <h3>Submit Expense (Employee)</h3>
          <form onSubmit={submitExpense}>
            <div><input placeholder="description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} required /></div>
            <div><input placeholder="amount" type="number" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} required /></div>
            <div>
              <select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
                <option value="misc">Misc</option>
                <option value="food">Food</option>
                <option value="travel">Travel</option>
              </select>
            </div>
            <div>
              <select value={form.currency} onChange={e=>setForm({...form,currency:e.target.value})}>
                <option value="">Select currency</option>
                {countries.map(ct => (
                  ct.currencyCodes.map(code => (
                    <option key={`${ct.name}-${code}`} value={code}>{code} — {ct.name}</option>
                  ))
                ))}
              </select>
            </div>
            <div>
              <input type="file" onChange={e=>setFile(e.target.files[0])} />
            </div>
            <button type="submit">Submit</button>
          </form>

          <h3 style={{marginTop:20}}>My Expenses / Pending (based on your role)</h3>
          <table border="1" cellPadding="6">
            <thead><tr><th>Description</th><th>Amount</th><th>Currency</th><th>Amount in Base</th><th>Category</th><th>Status</th><th>Receipt</th><th>Actions</th></tr></thead>
            <tbody>
              {expenses.map(exp=>(
                <tr key={exp.id}>
                  <td>{exp.description}</td>
                  <td>{exp.amount}</td>
                  <td>{exp.currency || '—'}</td>
                  <td>{exp.amountInBase ? exp.amountInBase.toFixed(2) : '—'}</td>
                  <td>{exp.category}</td>
                  <td>{exp.status}</td>
                  <td>{exp.receiptPath ? <a href={`http://localhost:4000${exp.receiptPath}`} target="_blank" rel="noreferrer">view</a> : '—'}</td>
                  <td>
                    <div>
                      <button onClick={()=>decision(exp.id, 'approve')}>Approve</button>
                      <button onClick={()=>decision(exp.id, 'reject')}>Reject</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{width:350}}>
          <h3>Admin: Create User</h3>
          <form onSubmit={createUser}>
            <div><input placeholder="name" value={newUser.name} onChange={e=>setNewUser({...newUser,name:e.target.value})} /></div>
            <div><input placeholder="email" value={newUser.email} onChange={e=>setNewUser({...newUser,email:e.target.value})} /></div>
            <div>
              <select value={newUser.role} onChange={e=>setNewUser({...newUser,role:e.target.value})}>
                <option value="employee">Employee</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <button type="submit">Create</button>
          </form>

          <h3 style={{marginTop:20}}>Existing Users (admin only)</h3>
          <ul>
            {users.map(u => <li key={u.email}>{u.name} — {u.email} ({u.role})</li>)}
          </ul>
        </div>
      </section>
    </div>
  );
}

export default App;
