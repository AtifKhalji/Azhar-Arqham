// backend/server.js
const express = require('express');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');
const multer = require('multer');
const cors = require('cors');
const bodyParser = require('body-parser');
const { nanoid } = require('nanoid');
const path = require('path');
const fs = require('fs');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// lowdb setup (file database)
const file = path.join(__dirname, 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);

// Ensure DB file exists and default structure
(async function initDB() {
  await db.read();
  db.data ||= { companies: [], users: [], expenses: [], approvalRules: [] };
  await db.write();
})();

// Multer for file uploads
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

// ---------------------------
// Currency cache for restcountries and conversion cache
// ---------------------------
let countriesCache = null;
let countriesCacheTime = 0;
const COUNTRIES_TTL = 1000 * 60 * 60; // 1 hour
let ratesCache = {}; // { 'USD_EUR': { rate, time } }
const RATES_TTL = 1000 * 60 * 30; // 30 minutes

// ---------------------------
// Helper functions
// ---------------------------
async function saveDB(){ await db.write(); }
async function findUserByEmail(email) {
  await db.read();
  return db.data.users.find(u => u.email === email);
}
function requireHeaderUser(req, res, next) {
  const email = req.header('x-user-email');
  if (!email) return res.status(401).json({ error: 'Set x-user-email header for demo auth' });
  req.userEmail = email;
  next();
}
async function requireUserRole(req, res, roles=[]) {
  await db.read();
  const user = db.data.users.find(u => u.email === req.userEmail);
  if (!user) return res.status(403).json({ error: 'User not found' });
  if (roles.length && !roles.includes(user.role)) {
    res.status(403).json({ error: 'Insufficient role' });
    throw new Error('role');
  }
  req.user = user;
}

async function getCompanyById(id) { await db.read(); return db.data.companies.find(c => c.id === id); }

async function fetchCountriesAndCurrencies() {
  const now = Date.now();
  if (countriesCache && (now - countriesCacheTime < COUNTRIES_TTL)) return countriesCache;
  const resp = await axios.get('https://restcountries.com/v3.1/all?fields=name,currencies');
  const data = resp.data.map(c => {
    const name = c.name && c.name.common ? c.name.common : '';
    const currs = c.currencies ? Object.keys(c.currencies) : [];
    return { name, currencyCodes: currs };
  }).filter(item => item.currencyCodes.length > 0);
  countriesCache = data;
  countriesCacheTime = now;
  return data;
}

async function convertToBaseCurrency(amount, fromCurrency, toCurrency) {
  if (!fromCurrency || !toCurrency) return amount;
  if (fromCurrency === toCurrency) return amount;
  const key = `${fromCurrency}_${toCurrency}`;
  const now = Date.now();
  if (ratesCache[key] && (now - ratesCache[key].time < RATES_TTL)) return amount * ratesCache[key].rate;
  // Use exchangerate.host free API
  try {
    const resp = await axios.get(`https://api.exchangerate.host/convert?from=${fromCurrency}&to=${toCurrency}`);
    if (resp.data && typeof resp.data.result === 'number') {
      ratesCache[key] = { rate: resp.data.result, time: now };
      return amount * resp.data.result;
    }
  } catch (err) {
    console.error('convert error', err.toString());
  }
  return amount; // fallback
}

// ---------------------------
// Routes
// ---------------------------

// Company signup
app.post('/api/company/signup', async (req, res) => {
  const { companyName, adminName, adminEmail, password, baseCurrency = 'USD' } = req.body;
  await db.read();
  if (!companyName || !adminEmail) return res.status(400).json({ error: 'Missing fields' });
  if (db.data.companies.some(c => c.companyName === companyName)) return res.status(400).json({ error: 'Company exists'});
  const companyId = nanoid(8);
  db.data.companies.push({ id: companyId, companyName, baseCurrency });
  db.data.users.push({ id: nanoid(), name: adminName || adminEmail.split('@')[0], email: adminEmail, password: password || null, role: 'admin', companyId });
  await saveDB();
  res.json({ message: 'Company and admin created', companyId });
});

// Admin: create user
app.post('/api/users', requireHeaderUser, async (req, res) => {
  try {
    await requireUserRole(req, res, ['admin']);
  } catch(e) { return; }
  const { name, email, role, managerEmail } = req.body;
  await db.read();
  if (db.data.users.find(u => u.email === email)) return res.status(400).json({ error: 'User exists' });
  const user = { id: nanoid(), name, email, role: role || 'employee', companyId: req.user.companyId, managerEmail: managerEmail || null };
  db.data.users.push(user);
  await saveDB();
  res.json({ user });
});

// Admin: set approval rule for category
app.post('/api/approval-rules', requireHeaderUser, async (req, res) => {
  try { await requireUserRole(req, res, ['admin']); } catch(e) { return; }
  const { category, approverEmails = [], minApprovalPercent = 100 } = req.body;
  if (!category) return res.status(400).json({ error: 'category required' });
  await db.read();
  const rule = { id: nanoid(), companyId: req.user.companyId, category, approverEmails, minApprovalPercent };
  db.data.approvalRules.push(rule);
  await saveDB();
  res.json({ rule });
});

// Get currency list (proxy to restcountries)
app.get('/api/currencies', async (req, res) => {
  try {
    const data = await fetchCountriesAndCurrencies();
    res.json(data);
  } catch (err) {
    console.error('countries fetch err', err.toString());
    res.status(500).json({ error: 'Failed to fetch currencies' });
  }
});

// Employee: submit expense
app.post('/api/expenses', requireHeaderUser, upload.single('receipt'), async (req, res) => {
  try { await requireUserRole(req, res, ['employee','manager','admin']); } catch(e) { return; }
  const { description, date, category, paidBy, amount, currency } = req.body;
  await db.read();
  const company = db.data.companies.find(c => c.id === req.user.companyId);
  const amountNum = parseFloat(amount) || 0;
  const amountInBase = await convertToBaseCurrency(amountNum, currency, company?.baseCurrency || 'USD');

  const expense = {
    id: nanoid(),
    ownerEmail: req.userEmail,
    companyId: req.user.companyId,
    description,
    date: date || new Date().toISOString(),
    category: category || 'misc',
    paidBy,
    amount: amountNum,
    currency: currency || null,
    amountInBase,
    receiptPath: req.file ? `/uploads/${req.file.filename}` : null,
    status: 'submitted',
    approvals: [],
    createdAt: new Date().toISOString()
  };
  db.data.expenses.push(expense);
  await saveDB();
  res.json({ expense });
});

// List expenses
app.get('/api/expenses', requireHeaderUser, async (req, res) => {
  try { await requireUserRole(req, res); } catch(e) { return; }
  await db.read();
  const u = req.user;
  if (u.role === 'employee') {
    const own = db.data.expenses.filter(e => e.ownerEmail === u.email);
    return res.json(own);
  }
  const status = req.query.status;
  let results = db.data.expenses.filter(e => e.companyId === u.companyId);
  if (status) results = results.filter(r => r.status === status);
  if (u.role === 'manager') {
    results = results.filter(e => {
      const assigned = db.data.approvalRules.some(r => r.companyId === u.companyId && r.approverEmails.includes(u.email) && r.category === e.category);
      const managerAssignedToUser = (db.data.users.find(x => x.email === e.ownerEmail)?.managerEmail === u.email);
      return assigned || managerAssignedToUser || e.approvals.some(a => a.approverEmail === u.email);
    });
  }
  res.json(results);
});

// Manager: decision
app.post('/api/expenses/:id/decision', requireHeaderUser, async (req, res) => {
  const { decision, note } = req.body;
  if (!['approve','reject'].includes(decision)) return res.status(400).json({ error: 'decision must be approve or reject' });
  try { await requireUserRole(req, res, ['manager','admin']); } catch(e) { return; }
  const id = req.params.id;
  await db.read();
  const expense = db.data.expenses.find(e => e.id === id);
  if (!expense) return res.status(404).json({ error: 'expense not found' });

  const approverEmail = req.userEmail;
  const rules = db.data.approvalRules.filter(r => r.companyId === req.user.companyId && r.category === expense.category);
  let allowed = false;
  if (req.user.role === 'admin') allowed = true;
  else {
    allowed = rules.some(r => r.approverEmails.includes(approverEmail)) || (db.data.users.find(u => u.email === expense.ownerEmail)?.managerEmail === approverEmail);
  }
  if (!allowed) return res.status(403).json({ error: 'Not authorized to approve this expense' });

  const record = { approverEmail, status: decision === 'approve' ? 'approved' : 'rejected', time: new Date().toISOString(), note: note || null };
  expense.approvals.push(record);

  let appliedRule = rules[0] || null;
  const approvals = expense.approvals.filter(a => a.status === 'approved').length;
  const totalApprovers = appliedRule ? appliedRule.approverEmails.length : (expense.approvals.length || 1);

  if (expense.approvals.some(a => a.status === 'rejected')) {
    expense.status = 'rejected';
  } else {
    const percent = Math.round((approvals / Math.max(totalApprovers,1)) * 100);
    const threshold = appliedRule ? appliedRule.minApprovalPercent : 100;
    if (percent >= threshold) expense.status = 'approved';
    else expense.status = 'pending';
  }
  await saveDB();
  res.json({ expense });
});

// User list (admin only)
app.get('/api/users', requireHeaderUser, async (req, res) => {
  try { await requireUserRole(req, res, ['admin']); } catch(e) { return; }
  await db.read();
  const users = db.data.users.filter(u => u.companyId === req.user.companyId);
  res.json(users);
});

// health
app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Expense backend running on ${PORT}`));
